#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <vector>
#include <QSharedPointer>
#include "fireobjects.h"

namespace Ui
{
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

protected:
    void renderFlames(bool withSharedMemory);
    
private:
    Ui::Dialog *m_ui;
    std::vector<FireObjects*> m_objects;
    QSharedPointer<QMovie> m_sharedMovie;
};

#endif // DIALOG_H
