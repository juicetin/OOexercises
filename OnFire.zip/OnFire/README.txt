To get this project to compile and run correctly copy FireAnimation.gif into the working directly of the application after building the application. Once that is done press go.

To test the difference between using the Flyweight and not using the Flyweight update line 11 of dialog.cpp to:

    renderFlames(true); // for flyweight or
	renderFlames(false); // for flyweight off