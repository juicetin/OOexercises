#include "fireobjects.h"
#include "dialog.h"

FireObjects::FireObjects(Dialog *dialog, int x, int y, QMovie *movie)
    : m_animation(movie)
    , m_objectLabel(new QLabel(dialog))
{
    m_animation->setScaledSize(QSize(200,100));

    m_objectLabel->setMovie(m_animation);
    m_objectLabel->setGeometry(QRect(x, y, 200, 200));
    m_animation->start();
}

FireObjects::~FireObjects()
{
    if (0 != m_objectLabel)
    {
        delete m_objectLabel;
        m_objectLabel = 0;
    }
}
