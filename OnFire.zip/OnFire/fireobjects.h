#ifndef FIREOBJECTS_H
#define FIREOBJECTS_H

#include <QLabel>
#include <QMovie>

class Dialog;

class FireObjects
{
public:
    FireObjects(Dialog *dialog, int x, int y, QMovie *movie = new QMovie("FireAnimation.gif"));
    ~FireObjects();

private:
    QLabel *m_objectLabel;
    QMovie *m_animation;
};

#endif // FIREOBJECTS_H
