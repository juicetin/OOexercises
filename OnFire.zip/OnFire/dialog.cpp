#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , m_ui(new Ui::Dialog)
{
    m_ui->setupUi(this);
    this->setFixedSize(1400, 800);
    this->setStyleSheet("background-color: #000000;");
    renderFlames(false);
}

Dialog::~Dialog()
{
    for (std::vector<FireObjects*>::iterator iter = m_objects.begin(); iter != m_objects.end(); ++iter)
    {
        delete *iter;
    }
    delete m_ui;
}

void Dialog::renderFlames(bool withSharedMemory)
{
    if (withSharedMemory)
    {
        m_sharedMovie = QSharedPointer<QMovie>(new QMovie("FireAnimation.gif"));
        for (int i = 100; i <= 1100; i += 200)
        {
            for (int j = 0; j <= 650; j+= 150)
            {
                 m_objects.push_back(new FireObjects(this, i, j, m_sharedMovie.data()));
            }
        }
    }
    else
    {
        for (int i = 100; i <= 1100; i += 200)
        {
            for (int j = 0; j <= 650; j+= 150)
            {
                 m_objects.push_back(new FireObjects(this, i, j));
            }
        }
    }
}
